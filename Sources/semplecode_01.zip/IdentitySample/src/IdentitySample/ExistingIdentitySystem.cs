﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentitySample
{
    public class ExistingIdentitySystem
    {
        // Methods
        public ExistingUser GetUserById(string userId)
        {
            // Result
            var user = new ExistingUser();
            user.Id = "Clark.Lab@hotmail.com";
            user.Name = "Clark";
            user.Birthday = DateTime.Now;

            // Return
            return user;
        }

        public bool PasswordSignIn(string userId, string password)
        {
            // Return
            return true;
        }

        public bool ExternalSignIn(string userId, string externalProvider)
        {
            switch (externalProvider)
            {
                case "Facebook": return true;

                default:
                    return true;
            }
        }
    }

    public class ExistingUser
    {
        // Properties
        public string Id { get; set; }

        public string Name { get; set; }

        public DateTime Birthday { get; set; }
    }
}
