﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using Microsoft.AspNet.Http.Authentication;
using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Http.Features.Authentication;
using Microsoft.AspNet.Authentication.Cookies;
using System.Security.Claims;

namespace IdentitySample.Controllers
{
    public class AccountController : Controller
    {
        // Methods
        public IActionResult Login(string returnUrl = null)
        {
            // ViewData
            this.ViewData["ReturnUrl"] = returnUrl;

            // Return
            return View();
        }

        public async Task<IActionResult> PasswordLogin(string userId, string password, string returnUrl = null)
        {
            // Login 
            var existingIdentitySystem = new ExistingIdentitySystem();
            if (existingIdentitySystem.PasswordSignIn(userId, password) == false)
            {
                throw new InvalidOperationException();
            }

            // ExistingUser
            var existingUser = existingIdentitySystem.GetUserById(userId);
            if (existingUser == null) throw new InvalidOperationException();

            // ApplicationUser
            var applicationIdentity = new ClaimsIdentity(IdentityOptions.Current.ApplicationCookieAuthenticationScheme, ClaimTypes.Name, ClaimTypes.Role);
            applicationIdentity.AddClaim(new Claim(ClaimTypes.NameIdentifier, existingUser.Id));
            applicationIdentity.AddClaim(new Claim(ClaimTypes.Name, existingUser.Name));

            var applicationUser = new ClaimsPrincipal(applicationIdentity);

            // Cookie
            await this.HttpContext.Authentication.SignInAsync(IdentityOptions.Current.ApplicationCookieAuthenticationScheme, applicationUser);
            await this.HttpContext.Authentication.SignOutAsync(IdentityOptions.Current.ExternalCookieAuthenticationScheme);

            // Return
            return Redirect(returnUrl);
        }
        
        public IActionResult ExternalLogin(string externalProvider, string returnUrl = null)
        {
            // AuthenticationProperties
            var authenticationProperties = new AuthenticationProperties();
            authenticationProperties.Items.Add("ExternalProvider", externalProvider);
            authenticationProperties.RedirectUri = Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl });

            // Return
            return new ChallengeResult(externalProvider, authenticationProperties);
        }

        public async Task<IActionResult> ExternalLoginCallback(string returnUrl = null)
        {
            // AuthenticateContext
            var authenticateContext = new AuthenticateContext(IdentityOptions.Current.ExternalCookieAuthenticationScheme);
            await this.HttpContext.Authentication.AuthenticateAsync(authenticateContext);

            // AuthenticateInfo           
            string userId = authenticateContext.Principal.FindFirst(ClaimTypes.Email).Value;
            string externalProvider = authenticateContext.Properties["ExternalProvider"] as string;

            // Login 
            var existingIdentitySystem = new ExistingIdentitySystem();
            if (existingIdentitySystem.ExternalSignIn(userId, externalProvider) == false)
            {
                throw new InvalidOperationException();
            }

            // ExistingUser
            var existingUser = existingIdentitySystem.GetUserById(userId);
            if (existingUser == null) throw new InvalidOperationException();

            // ApplicationUser
            var applicationIdentity = new ClaimsIdentity(IdentityOptions.Current.ApplicationCookieAuthenticationScheme, ClaimTypes.Name, ClaimTypes.Role);
            applicationIdentity.AddClaim(new Claim(ClaimTypes.NameIdentifier, existingUser.Id));
            applicationIdentity.AddClaim(new Claim(ClaimTypes.Name, existingUser.Name));

            var applicationUser = new ClaimsPrincipal(applicationIdentity);

            // Cookie
            await this.HttpContext.Authentication.SignInAsync(IdentityOptions.Current.ApplicationCookieAuthenticationScheme, applicationUser);
            await this.HttpContext.Authentication.SignOutAsync(IdentityOptions.Current.ExternalCookieAuthenticationScheme);

            // Return
            return Redirect(returnUrl);
        }
    }
}
