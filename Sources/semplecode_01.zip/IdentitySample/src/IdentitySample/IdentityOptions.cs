﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentitySample
{
    public class IdentityOptions
    {
        // Singleton
        private static IdentityOptions _current = null;

        public static IdentityOptions Current
        {
            get
            {
                if (_current == null)
                {
                    _current = new IdentityOptions();
                }
                return _current;
            }
        }


        // Properties
        public string ApplicationCookieAuthenticationScheme { get; set; } = typeof(IdentityOptions).Namespace + ".Application";

        public string ExternalCookieAuthenticationScheme { get; set; } = typeof(IdentityOptions).Namespace + ".External";
    }
}
