﻿using AOPTest;
using AOPTest3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AOPTest4
{
    public class RepositoryFactory
    {
        public static IRepository<T> Create<T>()
        {
            var repository = new Repository<T>();
            var decoratedRepository =
             new DynamicProxy<IRepository<T>>(
             repository).GetTransparentProxy() as IRepository<T>;
            // Create a dynamic proxy for the class already decorated
            decoratedRepository =
              new AuthenticationProxy<IRepository<T>>(
              decoratedRepository).GetTransparentProxy() as IRepository<T>;
            return decoratedRepository;
        }
    }
}
