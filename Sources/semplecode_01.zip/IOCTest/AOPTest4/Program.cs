﻿using AOPTest;
using AOPTest.POCO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AOPTest4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(
              "***\r\n Begin program - logging and authentication\r\n");
            Console.WriteLine("\r\nRunning as admin");
            Thread.CurrentPrincipal =
              new GenericPrincipal(new GenericIdentity("Administrator"),
               new[] { "ADMIN" });
            IRepository<Customer> customerRepository =
              RepositoryFactory.Create<Customer>();
            var customer = new Customer
            {
                Id = 1,
                Name = "Customer 1",
                Address = "Address 1"
            };
            customerRepository.Add(customer);
            customerRepository.Update(customer);
            customerRepository.Delete(customer);


            Console.WriteLine("\r\nRunning as user");
            Thread.CurrentPrincipal =
              new GenericPrincipal(new GenericIdentity("NormalUser"),
               new string[] { });
            customerRepository.Add(customer);
            customerRepository.Update(customer);
            customerRepository.Delete(customer);
            Console.WriteLine(
              "\r\nEnd program - logging and authentication\r\n***");
            Console.ReadLine();
        }
    }
}
