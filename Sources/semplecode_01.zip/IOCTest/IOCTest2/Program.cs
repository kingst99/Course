﻿using IOCTest2.DAL;
using IOCTest2.Interface;
using IOCTest2.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest2
{
    class Program
    {
        static void Main(string[] args)
        {
            //IDataAccess Idal = new SqlServerDal() as IDataAccess; //在外部的被依賴物件
            IDataAccess Idal = new AccessDal();

            Order order = new Order(Idal);//通過建構函數注入依賴物件實體

            order.Add();

            Console.Read();
        }
    }
}
