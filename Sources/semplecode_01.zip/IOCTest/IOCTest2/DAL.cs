﻿using IOCTest2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest2.DAL
{
    public class SqlServerDal : IDataAccess
    {
        public void Add()
        {
            Console.WriteLine("在SQL資料庫中添加一張訂單!");
        }
    }
}
