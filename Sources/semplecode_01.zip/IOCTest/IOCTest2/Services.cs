﻿using IOCTest2.DAL;
using IOCTest2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest2.Services
{
    public class Order
    {
        private IDataAccess _ida;//定义一个私有变量保存抽象

        //构造函数注入
        public Order(IDataAccess ida)
        {
            _ida = ida;//传递依赖
        }

        public void Add()
        {
            _ida.Add();
        }
    }
}
