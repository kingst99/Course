﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest2.Interface
{
    public interface IDataAccess
    {
        void Add();
    }
}
