﻿using IOCTest.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest.Services
{
    public class Order
    {
        //private readonly SqlServerDal dal = new SqlServerDal();
        private readonly AccessDal dal = new AccessDal();

        public void Add()
        {
            dal.Add();
        }
    }
}
