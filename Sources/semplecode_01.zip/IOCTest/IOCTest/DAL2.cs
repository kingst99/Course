﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOCTest.DAL
{
    public class AccessDal
    {
        public void Add()
        {
            Console.WriteLine("在ACCESS數據中添加一筆記錄!");
        }
    }
}
