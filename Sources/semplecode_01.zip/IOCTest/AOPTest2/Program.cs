﻿using AOPTest;
using AOPTest.POCO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AOPTest2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***\r\n Begin program - logging with decorator\r\n");
            // IRepository<Customer> customerRepository = 
            // new Repository<Customer>();
            IRepository<Customer> customerRepository =
              new LoggerRepository<Customer>(new Repository<Customer>());

            var customer = new Customer
            {
                Id = 1,
                Name = "Customer 1",
                Address = "Address 1"
            };
            customerRepository.Add(customer);
            customerRepository.Update(customer);
            customerRepository.Delete(customer);

            Console.WriteLine("\r\nEnd program - logging with decorator\r\n***");
            Console.ReadLine();
        }
    }
}
