﻿using AwesomeProxy;
using AwesomeProxy.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            var _format = "!yyyy/MM/dd hh:mm:ss#";

            var mc = new myClass();
            Console.WriteLine("執行原始物件myClass的GetCacheDate() : {0}", mc.GetCacheDate(_format));

            var mc2 = ProxyFactory.GetProxyInstance<myClass>();
            Console.WriteLine("使用代理物件執行myClass的GetCacheDate() : {0}", mc2.GetCacheDate(_format));

            Console.Read();
        }
    }

    public class myClass : MarshalByRefObject
    {
        [Test1]
        public string GetCacheDate(string formatStr)
        {
            return DateTime.Now.ToString(formatStr);
        }
    }
}
