﻿namespace TestDelegate
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.btnGirl = new System.Windows.Forms.Button();
            this.btnFriend = new System.Windows.Forms.Button();
            this.btnLoser = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "是誰來向我借錢：";
            // 
            // btnGirl
            // 
            this.btnGirl.AutoSize = true;
            this.btnGirl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnGirl.Location = new System.Drawing.Point(224, 32);
            this.btnGirl.Name = "btnGirl";
            this.btnGirl.Size = new System.Drawing.Size(147, 40);
            this.btnGirl.TabIndex = 1;
            this.btnGirl.Text = "正妹借30萬";
            this.btnGirl.UseVisualStyleBackColor = true;
            this.btnGirl.Click += new System.EventHandler(this.btnGirl_Click);
            // 
            // btnFriend
            // 
            this.btnFriend.AutoSize = true;
            this.btnFriend.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnFriend.Location = new System.Drawing.Point(121, 32);
            this.btnFriend.Name = "btnFriend";
            this.btnFriend.Size = new System.Drawing.Size(137, 40);
            this.btnFriend.TabIndex = 2;
            this.btnFriend.Text = "死黨借100";
            this.btnFriend.UseVisualStyleBackColor = true;
            this.btnFriend.Click += new System.EventHandler(this.btnFriend_Click);
            // 
            // btnLoser
            // 
            this.btnLoser.AutoSize = true;
            this.btnLoser.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnLoser.Location = new System.Drawing.Point(15, 32);
            this.btnLoser.Name = "btnLoser";
            this.btnLoser.Size = new System.Drawing.Size(143, 40);
            this.btnLoser.TabIndex = 3;
            this.btnLoser.Text = "魯蛇借十塊";
            this.btnLoser.UseVisualStyleBackColor = true;
            this.btnLoser.Click += new System.EventHandler(this.btnLoser_Click);
            // 
            // txtResult
            // 
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtResult.Location = new System.Drawing.Point(0, 63);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(334, 337);
            this.txtResult.TabIndex = 4;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "抽象",
            "虛擬",
            "委派"});
            this.comboBox1.Location = new System.Drawing.Point(213, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 38);
            this.comboBox1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 400);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnLoser);
            this.Controls.Add(this.btnFriend);
            this.Controls.Add(this.btnGirl);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name = "Form1";
            this.Text = "委派範例";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGirl;
        private System.Windows.Forms.Button btnFriend;
        private System.Windows.Forms.Button btnLoser;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

