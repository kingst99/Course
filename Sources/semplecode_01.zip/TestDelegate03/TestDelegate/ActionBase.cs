﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestDelegate
{
    internal abstract class ActionBase
    {
        /// <summary>
        /// 定義一個自訂借錢動作的委派(想像成是定義一個介面，規定參數及回傳型態就對了)
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public delegate string CustomAction(string amount);

        public CustomAction dCustomAction = (x) => $"原始委派------{x}------";
        //public CustomAction dCustomAction = myCustomAction;

        //public string myCustomAction(string amount)
        //{
        //    return "";
        //}

        public abstract string aCustomAction(string amount);

        public virtual string vCustomAction(string amount)
        {
            var resTemp = "原始虛擬函數-------{0}-------";
            return string.Format(resTemp, amount); ;
        }
    }
}
