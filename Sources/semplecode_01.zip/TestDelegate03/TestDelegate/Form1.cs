﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestDelegate
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        //public Func<string, string> CustomActionGirl = (x) => $"加碼借出{x}+{x}";
        //public Func<string, string> CustomActionFriend = (x) => $"借出{x}元";
        //public Func<string, string> CustomActionLoser = (x) => $"掉頭就走";

        /// <summary>
        /// 正妹來借錢了
        /// </summary>
        private void btnGirl_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            ActionBase customAction = new LendToGirl() as ActionBase;

            customAction.dCustomAction = (x) => $"借出{x}元";

            if (comboBox1.SelectedIndex == 0)
                LendAction("30萬", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("30萬", customAction);
            else
                dLendAction("30萬", customAction);
        }

        /// <summary>
        /// 死黨來借錢了
        /// </summary>
        private void btnFriend_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            var customAction = new LendToFriend() as ActionBase;

            if (comboBox1.SelectedIndex == 0)
                LendAction("100", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("100", customAction);
            else
                dLendAction("100", customAction);
        }

        /// <summary>
        /// 魯蛇來借錢了
        /// </summary>
        private void btnLoser_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            var customAction = new LendToLoser() as ActionBase;

            if (comboBox1.SelectedIndex == 0)
                LendAction("10", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("10", customAction);
            else
                dLendAction("10", customAction);
        }

        /// <summary>
        /// 借錢動作
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="customAct"></param>
        private void LendAction(string amount, ActionBase customAct)
        {
            txtResult.Text = string.Empty;

            //決定要借出的金額
            string finalAmount;

            //我們不需要知道這個customAct到底是什麼
            //反正他跑完會回傳一個我們要的東西就對了
            //在這裡回傳的就是最終借出金額
            finalAmount = customAct.aCustomAction(amount);

            txtResult.Text += finalAmount;
        }

        /// <summary>
        /// 借錢動作
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="customAct"></param>
        private void vLendAction(string amount, ActionBase customAct)
        {
            txtResult.Text = string.Empty;

            //決定要借出的金額
            string finalAmount;

            //我們不需要知道這個customAct到底是什麼
            //反正他跑完會回傳一個我們要的東西就對了
            //在這裡回傳的就是最終借出金額
            finalAmount = customAct.vCustomAction(amount);

            txtResult.Text += $"(v){finalAmount}";
        }

        /// <summary>
        /// 借錢動作
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="customAct"></param>
        private void dLendAction(string amount, ActionBase customAct)
        {
            txtResult.Text = string.Empty;

            //決定要借出的金額
            string finalAmount;

            //我們不需要知道這個customAct到底是什麼
            //反正他跑完會回傳一個我們要的東西就對了
            //在這裡回傳的就是最終借出金額
            finalAmount = customAct.dCustomAction(amount);

            txtResult.Text += $"(v){finalAmount}";
        }
    }

    class LendToGirl : ActionBase
    {
        /// <summary>
        /// 借錢給正妹的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            var res =
@"詢問正妹：真的只要借{0}元嗎?夠不夠啊?
詢問正妹：要幫妳買點數卡嗎?
詢問正妹：可以加妳的Line嗎?
詢問正妹：妳幾歲呀?
詢問正妹：妳住哪?
詢問正妹：妳有男朋友嗎?
詢問正妹：妳三圍多少?
詢問正妹：禮拜六有空嗎?
...
.....
....
哇!服務這麼好喔!
....
.....
GGInInDer
OK~沒問題!
....
...去提款機領{0}元
";
            return string.Format(res, amount);
        }

        public override string vCustomAction(string amount)
        {
            var res =
@"詢問正妹：真的只要借{0}元嗎?夠不夠啊?
詢問正妹：要幫妳買點數卡嗎?
詢問正妹：可以加妳的Line嗎?
詢問正妹：妳幾歲呀?
詢問正妹：妳住哪?
詢問正妹：妳有男朋友嗎?
詢問正妹：妳三圍多少?
詢問正妹：禮拜六有空嗎?
...
.....
....
哇!服務這麼好喔!
....
.....
GGInInDer
OK~沒問題!
....
...去提款機領{0}元
";
            return string.Format(res, amount);
        }

    }
    class LendToFriend : ActionBase
    {
        /// <summary>
        /// 借錢給死檔的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            var res =
   @"幹...
(錢包掏出{0}元)
";
            return string.Format(res, amount);
        }

        public override string vCustomAction(string amount)
        {
            var res =
   @"幹...
(錢包掏出{0}元)
";
            return string.Format(res, amount);
        }
    }
    class LendToLoser : ActionBase
    {
        /// <summary>
        /// 借錢給魯蛇的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            return "掉頭就走";
        }
    }
}
