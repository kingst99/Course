﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestDelegate
{
    class LendToGirl : ActionBase
    {
        /// <summary>
        /// 借錢給正妹的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            var res =
@"詢問正妹：真的只要借{0}元嗎?夠不夠啊?
詢問正妹：要幫妳買點數卡嗎?
詢問正妹：可以加妳的Line嗎?
詢問正妹：妳幾歲呀?
詢問正妹：妳住哪?
詢問正妹：妳有男朋友嗎?
詢問正妹：妳三圍多少?
詢問正妹：禮拜六有空嗎?
...
.....
....
哇!服務這麼好喔!
....
.....
GGInInDer
OK~沒問題!
....
...去提款機領{0}元
";
            return string.Format(res, amount);
        }
    }
    class LendToFriend : ActionBase
    {
        /// <summary>
        /// 借錢給死檔的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            var res =
   @"幹...
(錢包掏出{0}元)
";
            return string.Format(res, amount);
        }

        public override string vCustomAction(string amount)
        {
            var res =
   @"(v)幹...
(錢包掏出{0}元)
";
            return string.Format(res, amount); ;
        }
    }
    class LendToLoser : ActionBase
    {
        /// <summary>
        /// 借錢給魯蛇的自訂動作
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public override string aCustomAction(string amount)
        {
            return "掉頭就走";
        }
    }
}
