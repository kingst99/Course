﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestDelegate
{
    internal abstract class ActionBase
    {
        public abstract string aCustomAction(string amount);

        public virtual string vCustomAction(string amount)
        {
            var resTemp = "原始虛擬函數-------{0}-------";
            return string.Format(resTemp, amount); ;
        }
    }
}
