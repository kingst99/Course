﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestDelegate
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        /// <summary>
        /// 正妹來借錢了
        /// </summary>
        private void btnGirl_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            ActionBase customAction = new LendToGirl() as ActionBase;

            if (comboBox1.SelectedIndex == 0)
                LendAction("30萬", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("30萬", customAction);
        }

        /// <summary>
        /// 死黨來借錢了
        /// </summary>
        private void btnFriend_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            var customAction = new LendToFriend() as ActionBase;

            if (comboBox1.SelectedIndex == 0)
                LendAction("100", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("100", customAction);
        }

        /// <summary>
        /// 魯蛇來借錢了
        /// </summary>
        private void btnLoser_Click(object sender, EventArgs e)
        {
            //只要是符合ActionBase這個型別，就可以指定給他
            var customAction = new LendToLoser() as ActionBase;

            if (comboBox1.SelectedIndex == 0)
                LendAction("10", customAction);
            else if (comboBox1.SelectedIndex == 1)
                vLendAction("10", customAction);
        }

        /// <summary>
        /// 抽象函式 借錢動作
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="customAct"></param>
        private void LendAction(string amount, ActionBase customAct)
        {
            txtResult.Text = string.Empty;

            //決定要借出的金額
            string finalAmount;

            //我們不需要知道這個customAct到底是什麼
            //反正他跑完會回傳一個我們要的東西就對了
            //在這裡回傳的就是最終借出金額
            finalAmount = customAct.aCustomAction(amount);

            txtResult.Text += finalAmount;
        }

        /// <summary>
        /// 虛擬函式 借錢動作
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="customAct"></param>
        private void vLendAction(string amount, ActionBase customAct)
        {
            txtResult.Text = string.Empty;

            //決定要借出的金額
            string finalAmount;

            //我們不需要知道這個customAct到底是什麼
            //反正他跑完會回傳一個我們要的東西就對了
            //在這裡回傳的就是最終借出金額
            finalAmount = customAct.vCustomAction(amount);

            txtResult.Text += $"(v){finalAmount}";
        }
        
    }
}
