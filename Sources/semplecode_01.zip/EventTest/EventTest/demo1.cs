﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventTest
{
    public static class demo1
    {
        public static void Demo()
        {
            Counter c = new Counter(new Random().Next(10));
            c.ThresholdReached += c_ThresholdReached1;
            c.ThresholdReached += c_ThresholdReached2;

            Console.WriteLine("press 'a' key to increase total");
            while (Console.ReadKey(true).KeyChar == 'a')
            {
                Console.WriteLine("adding one");
                c.Add(1);
            }
        }

        static void c_ThresholdReached1(object sender, EventArgs e)
        {
            Console.WriteLine("The threshold was reached.");
            Console.ReadLine();
        }
        static void c_ThresholdReached2(object sender, EventArgs e)
        {
            Console.WriteLine("The threshold was reached.");
            Console.ReadLine();
            Environment.Exit(0);
        }

        class Counter
        {
            private int threshold;
            private int total;

            public Counter(int passedThreshold)
            {
                threshold = passedThreshold;
            }

            public void Add(int x)
            {
                total += x;
                if (total >= threshold)
                {
                    OnThresholdReached(EventArgs.Empty);
                }
            }

            protected virtual void OnThresholdReached(EventArgs e)
            {
                EventHandler<EventArgs> handler = ThresholdReached;
                //ThresholdReached_EvevtHander handler = ThresholdReached;

                if (handler != null)
                {
                    handler(this, e);
                }
            }

            public EventHandler<EventArgs> ThresholdReached;
            //public event ThresholdReached_EvevtHander ThresholdReached;
            //public delegate void ThresholdReached_EvevtHander(object sender, EventArgs args);
        }
    }
}
