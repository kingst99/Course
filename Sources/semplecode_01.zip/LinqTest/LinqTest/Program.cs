﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //C#
            //DelegateExample.Do();
            //Func.Do();
            //GenericFunc.Do();
            //Anonymous.Do();
            //LambdaExpression.Do();
            //ExpressionTree.Do();
            //ExpressionTree.Do2();

            //Func<int, int> func2 = x => x;
            //Console.WriteLine(func2(9));

            Console.ReadLine();


            Action<string> SayHello = new Action<string>(ChineseSay); // 方式一
            Action<string> SayName = ChineseSay; // 方式二
            Action<string> SayAge = s => Console.WriteLine(" 我今年{0}歲了", s); // 方式三
            SayHello("您好");
            SayName.Invoke(" 我叫Wolfy ");
            IAsyncResult result = SayAge.BeginInvoke(" 27 ", CallBack, " 愛好女");
            if (result.IsCompleted)
            {
                SayAge.EndInvoke(result);
            }
            Console.Read();
        }

        private static void CallBack(IAsyncResult ar)
        {
            Console.WriteLine(" 介紹完畢，忘了，我{0},我不搞基", ar.AsyncState.ToString());
        }
        ///  <summary> 
        /// 委託對應方法
        ///  </summary> 
        ///  <param name="strContent"></param> 
        private static void ChineseSay(string strContent)
        {
            Console.WriteLine(strContent);
        }

        //public delegate TResult Func<in T, out TResult>(T arg);

    }
}
