﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTest
{
    public static class LambdaExpression
    {

        public static void Do()
        {
            Func<string, string> convert = s => s.ToUpper();

            string name = "Dakota";
            Console.WriteLine(convert(name));
        }

    }
}
