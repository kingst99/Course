﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTest
{
    public static class Func
    {

        public static void Do()
        {
            // Declare a Func variable and assign a lambda expression to the  
            // variable. The method takes a string and converts it to uppercase.
            Func<string, string> selector = str => str.ToUpper();

            // Create an array of strings.
            string[] words = { "orange", "apple", "Article", "elephant" };
            // Query the array and select strings according to the selector method.
            //IEnumerable<String> aWords = words.Select(selector);

            IEnumerable<String> aWords = words.Select(delegate (String x) { return x.ToUpper(); });

            //IEnumerable<String> aWords = words.Select(x => x.ToUpper());

            // Output the results to the console.
            foreach (String word in aWords)
                Console.WriteLine(word);
        }

    }
}
