﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTest
{
    public static class Anonymous
    {

        public static void Do()
        {
            Func<string, string> convert = delegate (string s)
            { return s.ToUpper(); };

            string name = "Dakota";
            Console.WriteLine(convert(name));
        }

    }
}
